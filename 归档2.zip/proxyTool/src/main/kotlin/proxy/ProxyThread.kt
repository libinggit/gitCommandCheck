package proxy

import java.net.ServerSocket

/**
 * 代理线程。
 */
class ProxyThread (private val port:Int): Thread() {
    override fun run() {
        val socketServer = ServerSocket(port)
        while (true){
            try {
                val socketClient = socketServer.accept()
                HttpConnectThread(socketClient).start()
            }catch (e:java.lang.Exception){
                e.printStackTrace()
            }

        }
    }
}