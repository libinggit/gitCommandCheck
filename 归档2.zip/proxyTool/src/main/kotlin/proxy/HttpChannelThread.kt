package proxy

import utils.IOUtils
import utils.SecretUtils
import utils.copyToExt
import java.io.DataInputStream
import java.io.DataOutputStream
import java.util.concurrent.CountDownLatch

/**
 * 从输入流读取数据输出到输出流
 * @param secret true是加密 false是解密
 */
class HttpChannelThread(private val secret:Boolean,private val input:DataInputStream, private val output:DataOutputStream, private val countDownLatch: CountDownLatch):Thread() {

    override fun run() {
        input.copyToExt(output)
    }

//    override fun run() {
//        try {
//            if(secret){
//                output.write(getInputByteArray(input))
////                output.flush()
//            }else{
//                output.write(getInputByteArray(input))
////                output.flush()
//            }
//        }catch (e:java.lang.Exception){
//            e.printStackTrace()
//        }finally {
//            IOUtils.close(input,output)
//            countDownLatch.countDown()
//        }
//    }
//
//    private fun getInputByteArray(input:DataInputStream):ByteArray{
//        return getBufferByteArray(input, ByteArray(0))
//    }
//
//    private fun getBufferByteArray(input:DataInputStream,byteArray: ByteArray):ByteArray{
//        val buffer = ByteArray(1024)
//        val size =input.read(buffer)
//
//        return if(size<0){
//            byteArray
//        }else{
//            val realByteArray = ByteArray(size+byteArray.size)
//            System.arraycopy(byteArray,0,realByteArray,0,byteArray.size)
//            System.arraycopy(buffer,0,realByteArray,byteArray.size,size)
//            return getBufferByteArray(input,realByteArray)
//        }
//    }
}