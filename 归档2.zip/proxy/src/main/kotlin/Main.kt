import proxy.ProxyThread
import utils.ThreadUtils

fun main(args: Array<String>) {
    ThreadUtils.run(ProxyThread(8888))
}