package utils

import java.util.concurrent.Executors

/**
 * 线程池
 */
object ThreadUtils {
    private val threadPool = Executors.newScheduledThreadPool(20)
    fun run(runnable: Runnable){
        threadPool.execute(runnable)
    }
}