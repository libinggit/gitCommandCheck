package proxy

import utils.IOUtils
import utils.SecretUtils
import utils.ThreadUtils
import utils.ext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * 处理客户端发来的数据，从而代理。
 */
class HttpConnectThread(private val client: Socket) : Runnable {
    override fun run() {
        val clientInputStream = DataInputStream(client.getInputStream())
        val clientOutputStream = DataOutputStream(client.getOutputStream())

        val clientInputByteArray = ByteArray(1024 * 1024 * 4)
        val clientReadLength = clientInputStream.read(clientInputByteArray, 0, clientInputByteArray.size)
        var serverInfo: ServerInfo? = null
        try {
            if (clientReadLength > 0) {
                val clientInputByteArraySecret = ByteArray(clientReadLength)
                System.arraycopy(clientInputByteArray,0,clientInputByteArraySecret,0,clientReadLength)
                clientInputByteArraySecret.ext()
                var clientInputString = SecretUtils.decrypt(clientInputByteArraySecret)?.let { String(it) }?:""
                println("客户端请求的数据为:$clientInputString")
                if (clientInputString.contains("\n")) {
                    clientInputString = clientInputString.substring(0, clientInputString.indexOf("\n"))
                }
                // 是不是连接
                var isConnectCmd = false
                serverInfo = if (clientInputString.contains("CONNECT ")) {
                    isConnectCmd = true
                    parseHost(clientInputString, "CONNECT ([^ ]+) HTTP/")
                } else {
                    isConnectCmd = false
                    parseHost(clientInputString, "http://([^/]+)/")
                }

                val remoteSocket = Socket(serverInfo.serverHost, serverInfo.serverPort)
                val serverInputStream = DataInputStream(remoteSocket.getInputStream())
                val serverOutputStream = DataOutputStream(remoteSocket.getOutputStream())
                handleProxy(
                    isConnectCmd,
                    clientInputString,
                    clientInputByteArray,
                    clientReadLength,
                    clientInputStream,
                    clientOutputStream,
                    serverInputStream,
                    serverOutputStream
                )
                IOUtils.close(
                    remoteSocket,
                    clientInputStream,
                    clientOutputStream,
                    serverInputStream,
                    serverOutputStream
                )
            }
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
        } finally {

        }

    }

    /**
     * 处理连接请求。
     */
    private fun handleProxy(
        isConnectCmd: Boolean,
        clientInputString: String,
        clientInputByteArray: ByteArray,
        clientReadLength: Int,
        clientInputStream: DataInputStream,
        clientOutputStream: DataOutputStream,
        serverInputStream: DataInputStream,
        serverOutputStream: DataOutputStream
    ) {
        if (isConnectCmd) {
            val ack = "HTTP/1.0 200 Connection established\r\nProxy-agent: proxy\r\n\r\n"
            val byteArray = ack.toByteArray()
            byteArray.ext()
            clientOutputStream.write(byteArray)
            clientOutputStream.flush()
            val latch = CountDownLatch(2)
            // 建立线程 , 用于从外网读数据 , 并返回给内网
            ThreadUtils.run(HttpChannelThread(true,serverInputStream, clientOutputStream, latch))
            // 建立线程 , 用于从内网读数据 , 并返回给外网
            ThreadUtils.run(HttpChannelThread(false,clientInputStream, serverOutputStream, latch))
            latch.await(120, TimeUnit.SECONDS)
            IOUtils.close(serverInputStream, serverOutputStream, clientInputStream, clientOutputStream, client)
        } else {
            serverOutputStream.write(clientInputByteArray, 0, clientReadLength)
            serverOutputStream.flush()
            val latch: CountDownLatch
            if (clientInputString.contains("POST ")) {
                latch = CountDownLatch(2)
                // 建立线程 , 用于从内网读数据 , 并返回给外网
                ThreadUtils.run(HttpChannelThread(false,clientInputStream, serverOutputStream, latch))
            } else {
                latch = CountDownLatch(1)
            }
            // 建立线程 , 用于从外网读数据 , 并返回给内网
            ThreadUtils.run(HttpChannelThread(true,serverInputStream, clientOutputStream, latch))
            latch.await(120, TimeUnit.SECONDS)
            IOUtils.close(serverInputStream, serverOutputStream, clientInputStream, clientOutputStream, client)
        }


    }

    /***
     * 解析主机地址
     */
    private fun parseHost(clientInputString: String, regExp: String): ServerInfo {
        val pattern: Pattern = Pattern.compile(regExp)
        val matcher = pattern.matcher("$clientInputString/")
        var host = ""
        var port = 0
        if (matcher.find()) {
            host = matcher.group(1)
            if (host.contains(":")) {
                port = host.substring(host.indexOf(":") + 1).toInt()
                host = host.substring(0, host.indexOf(":"))
            }
        }
        return ServerInfo(host, port)
    }
}

data class ServerInfo(
    /**
     * 主机地址
     */
    val serverHost: String,
    /**
     * 主机端口
     */
    val serverPort: Int
)