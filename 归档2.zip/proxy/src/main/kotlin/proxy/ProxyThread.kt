package proxy

import utils.ThreadUtils
import java.net.ServerSocket

/**
 * 代理线程。
 */
class ProxyThread (private val port:Int): Runnable {
    override fun run() {
        val socketServer = ServerSocket(port)
        while (true){
            try {
                System.gc()
                val socketClient = socketServer.accept()
                ThreadUtils.run(HttpConnectThread(socketClient))
            }catch (e:java.lang.Exception){
                e.printStackTrace()
            }

        }
    }
}