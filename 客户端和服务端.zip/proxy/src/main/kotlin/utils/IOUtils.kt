package utils

import java.io.Closeable
import java.io.IOException




object IOUtils {
    /**
     * 关闭所有流
     */
    fun close(vararg closeables: Closeable?) {
        for (close in closeables) {
            try {
                close?.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }
}