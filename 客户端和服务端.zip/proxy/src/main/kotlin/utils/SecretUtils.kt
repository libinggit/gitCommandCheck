package utils

import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.SecretKeySpec


/**
 * 加解密类。
 */
object SecretUtils {
    private val key = "a5g6htr8".toByteArray()
    /**
     * 生成密钥
     * @throws Exception
     */
    @Throws(Exception::class)
    fun initKey(): ByteArray? {
        //密钥生成器
        val keyGen = KeyGenerator.getInstance("DES")
        //初始化密钥生成器
        keyGen.init(56)
        //生成密钥
        val secretKey = keyGen.generateKey()
        return secretKey.encoded
    }

    /**
     * 加密
     * @throws Exception
     */
    @Throws(Exception::class)
    fun encryptDES(data: ByteArray?, key: ByteArray?): ByteArray? {
        //获得密钥
        val secretKey: SecretKey = SecretKeySpec(key, "DES")
        //Cipher完成加密
        val cipher = Cipher.getInstance("DES")
        //初始化cipher
        cipher.init(Cipher.ENCRYPT_MODE, secretKey)
        //加密
        return cipher.doFinal(data)
    }

    /**
     * 解密
     */
    @Throws(Exception::class)
    fun decryptDES(data: ByteArray?, key: ByteArray?): ByteArray? {
        //恢复密钥
        val secretKey: SecretKey = SecretKeySpec(key, "DES")
        //Cipher完成解密
        val cipher = Cipher.getInstance("DES")
        //初始化cipher
        cipher.init(Cipher.DECRYPT_MODE, secretKey)
        //解密
        return cipher.doFinal(data)
    }

    fun encrypt(data: ByteArray?):ByteArray?{
        val result = encryptDES(data, key)
//        val result2= ByteArray(result?.size?:0+1)
//        result2[0] = Byte.MAX_VALUE
//        System.arraycopy(result,0,result2,1,result?.size?:0)
        return data
    }

    fun decrypt(data: ByteArray?): ByteArray? {
//        val result = ByteArray(data?.size?:1-1)
//        System.arraycopy(data,1,result,0,result.size)
        return data
    }
}
