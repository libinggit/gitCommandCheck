import proxy.ProxyThread

fun main(args: Array<String>) {
    ProxyThread(8888).start()
}