import proxy.ProxyThread
import utils.SecretUtils

fun main(args: Array<String>) {
    ProxyThread(8888).start()
//    println(SecretUtils.initKey()?.size)
//    val str="212121212"
//    val pwd="a5g6htr8"
//    val secret = SecretUtils.encryptDES(str.toByteArray(),pwd.toByteArray())
//
//    println(SecretUtils.decryptDES(secret,pwd.toByteArray())?.let { String(it) })
}