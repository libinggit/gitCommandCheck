package proxy

import utils.IOUtils
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * 处理客户端发来的数据，从而代理。
 */
class HttpConnectThread(private val client: Socket) : Thread() {
    override fun run() {
        val clientInputStream = DataInputStream(client.getInputStream())
        val clientOutputStream = DataOutputStream(client.getOutputStream())

        val remoteSocket = Socket("43.133.62.199", 8888)
        val serverInputStream = DataInputStream(remoteSocket.getInputStream())
        val serverOutputStream = DataOutputStream(remoteSocket.getOutputStream())

        handleProxy(clientInputStream, clientOutputStream, serverInputStream, serverOutputStream)
    }

    /**
     * 处理连接请求。
     */
    private fun handleProxy(
        clientInputStream: DataInputStream,
        clientOutputStream: DataOutputStream,
        serverInputStream: DataInputStream,
        serverOutputStream: DataOutputStream
    ) {
        val latch = CountDownLatch(2)
        // 建立线程 , 用于从外网读数据 , 并返回给内网
        HttpChannelThread(false,serverInputStream, clientOutputStream, latch).start()
        // 建立线程 , 用于从内网读数据 , 并返回给外网
        HttpChannelThread(true,clientInputStream, serverOutputStream, latch).start()
        latch.await(120, TimeUnit.SECONDS)
        IOUtils.close(serverInputStream, serverOutputStream, clientInputStream, clientOutputStream, client)

    }
}