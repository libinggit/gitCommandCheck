package utils

import java.io.InputStream
import java.io.OutputStream

/**
 * Byte -128 到127
 * 加密策略，-127 - -1 转换为127-1
 * 1-127 转换为-1 - -127
 * 0 和 -128 不管
 */
fun InputStream.copyToExt(out: OutputStream, bufferSize: Int = DEFAULT_BUFFER_SIZE): Long {
    var bytesCopied: Long = 0
    val buffer = ByteArray(bufferSize)
    var bytes = read(buffer)
    while (bytes >= 0) {
        buffer.ext()
        out.write(buffer, 0, bytes)
        bytesCopied += bytes
        bytes = read(buffer)
    }
    return bytesCopied
}

fun ByteArray.ext(){
    for(i in this.indices){
        if( this[i].equals(0)||this[i].equals(-128)){
            continue
        }
        this[i] = (-this[i]).toByte()
    }
}